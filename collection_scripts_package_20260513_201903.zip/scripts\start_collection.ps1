$ErrorActionPreference = "Continue"

$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$PythonExe = Join-Path $ProjectDir ".venv\Scripts\python.exe"
$DockerDesktop = "C:\Program Files\Docker\Docker\Docker Desktop.exe"
$HomeAssistantUrl = "http://localhost:8123"

$Scripts = @(
    "read_arduino.py",
    "philips_hue_to_mqtt.py",
    "tapo_p110_to_mqtt.py",
    "dreo_ha_to_mqtt.py",
    "collect_all_mqtt.py"
)

function Test-UrlOk {
    param([string]$Url)
    try {
        $response = Invoke-WebRequest -Uri $Url -UseBasicParsing -TimeoutSec 5
        return $response.StatusCode -eq 200
    } catch {
        return $false
    }
}

function Ensure-HomeAssistant {
    if (Test-UrlOk $HomeAssistantUrl) {
        Write-Host "[OK] Home Assistant is reachable at $HomeAssistantUrl"
        return
    }

    Write-Host "[INFO] Home Assistant is not reachable. Trying to start Docker Desktop..."
    if (Test-Path $DockerDesktop) {
        Start-Process -FilePath $DockerDesktop -WindowStyle Hidden
        Start-Sleep -Seconds 25
    } else {
        Write-Host "[WARN] Docker Desktop was not found at: $DockerDesktop"
    }

    try {
        $container = docker ps -a --filter "name=homeassistant" --format "{{.Names}} {{.Status}}"
        if ($container -match "homeassistant") {
            docker start homeassistant | Out-Null
            Write-Host "[INFO] Started Home Assistant container."
        } else {
            Write-Host "[WARN] Home Assistant container was not found."
        }
    } catch {
        Write-Host "[WARN] Docker command failed. You may need to start Docker Desktop manually."
    }

    for ($i = 1; $i -le 12; $i++) {
        if (Test-UrlOk $HomeAssistantUrl) {
            Write-Host "[OK] Home Assistant is reachable at $HomeAssistantUrl"
            return
        }
        Write-Host "[INFO] Waiting for Home Assistant... ($i/12)"
        Start-Sleep -Seconds 5
    }

    Write-Host "[WARN] Home Assistant is still not reachable. Dreo script may fail until HA is up."
}

function Test-ScriptRunning {
    param([string]$ScriptName)
    $escaped = [regex]::Escape($ScriptName)
    $processes = Get-CimInstance Win32_Process -Filter "Name = 'python.exe'" -ErrorAction SilentlyContinue |
        Where-Object { $_.CommandLine -match "PythonProject" -and $_.CommandLine -match $escaped }
    return $null -ne $processes
}

function Start-CollectorScript {
    param([string]$ScriptName)

    $scriptPath = Join-Path $ProjectDir $ScriptName
    if (-not (Test-Path $scriptPath)) {
        Write-Host "[WARN] Missing script: $scriptPath"
        return
    }

    if (Test-ScriptRunning $ScriptName) {
        Write-Host "[SKIP] Already running: $ScriptName"
        return
    }

    $title = "IoT Collector - $ScriptName"
    $command = "cd /d `"$ProjectDir`" && title $title && `"$PythonExe`" `"$scriptPath`""
    Start-Process -FilePath "cmd.exe" -ArgumentList "/k", $command -WorkingDirectory $ProjectDir
    Write-Host "[START] $ScriptName"
    Start-Sleep -Seconds 1
}

if (-not (Test-Path $PythonExe)) {
    Write-Host "[ERROR] Python venv not found: $PythonExe"
    exit 1
}

Write-Host "========================================"
Write-Host " IoT Data Collection Launcher"
Write-Host " Project: $ProjectDir"
Write-Host "========================================"

Ensure-HomeAssistant

foreach ($script in $Scripts) {
    Start-CollectorScript $script
}

Write-Host "========================================"
Write-Host "[DONE] Collection scripts requested."
Write-Host "CSV output: $(Join-Path $ProjectDir 'aligned_all_data_clean.csv')"
Write-Host "Close each opened window, or press Ctrl+C inside it, to stop."
Write-Host "========================================"
