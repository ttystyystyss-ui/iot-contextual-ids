﻿# Collection Scripts Package

This package contains the data collection and device control scripts for the smart-home IDS project.

## Scripts

- scripts/collect_all_mqtt.py: subscribes to MQTT topics and writes aligned CSV data.
- scripts/read_arduino.py: reads Arduino serial sensor data and publishes MQTT messages.
- scripts/philips_hue_to_mqtt.py: reads Philips Hue light state locally and publishes MQTT messages.
- scripts/tapo_p110_to_mqtt.py: reads Tapo P110 power and publishes MQTT messages.
- scripts/dreo_ha_to_mqtt.py: reads Dreo fan state via Home Assistant and publishes MQTT messages.
- scripts/hue_control.py: controls Hue light locally for automated testing.
- scripts/dreo_fan_control.py: controls Dreo fan for automated testing.
- scripts/start_collection.ps1: starts the collection pipeline in separate processes.
- scripts/start_collection.bat: batch wrapper for starting collection.

## Typical Collection Start

From this package root:

`powershell
cd .\scripts
.\start_collection.ps1
`

Or run scripts manually in PyCharm/terminal.

## Typical Automation Commands

Hue light random loop:

`powershell
python .\hue_control.py loop --random --min-interval 8 --max-interval 20 --count 0
`

Dreo fan random loop:

`powershell
python .\dreo_fan_control.py loop --random --min-interval 40 --max-interval 120 --count 0 --percentage 50
`

## Requirements

`powershell
pip install paho-mqtt requests python-kasa pyserial
`

Home Assistant/Dreo access may also require your existing local Home Assistant setup.
