import argparse
import csv
import json
import time
from datetime import datetime, timezone
from pathlib import Path

import paho.mqtt.client as mqtt
import torch

from train_gnn_gru_ids import (
    GATGRUPredictor,
    NODE_NAMES,
    PHYSICAL_NODES,
    StandardScaler,
    build_edge_index,
)


MODEL_PATH = "artifacts/gnn_gru_ids_run/gnn_gru_ids.pt"
MQTT_BROKER = "172.24.224.223"
MQTT_PORT = 1883
MQTT_TOPICS = [
    "iot/arduino",
    "iot/light_state",
    "iot/tapo_p110",
    "iot/dreo_fan",
]
ALERT_TOPIC = "iot/gnn_gru_ids_alert"
ONLINE_LOG = Path("artifacts/gnn_gru_ids_online_log.csv")
LOG_FIELDS = [
    "time",
    "status",
    "skipped_reason",
    "history",
    "required_history",
    "anomaly",
    "high_error",
    "total_high_error",
    "target_high_error",
    "consecutive_high_error",
    "error",
    "threshold",
    "prediction_start_time",
    "prediction_end_time",
    "prediction_horizon",
    "light_state",
    "fan_state",
    "err_ambient_light",
    "err_temperature",
    "err_total_power_w",
    "th_ambient_light",
    "th_temperature",
    "th_total_power_w",
    "actual_ambient_light",
    "actual_temperature",
    "actual_total_power_w",
    "pred_ambient_light",
    "pred_temperature",
    "pred_total_power_w",
    "actual_delta_ambient_light",
    "actual_delta_temperature",
    "actual_delta_total_power_w",
    "pred_delta_ambient_light",
    "pred_delta_temperature",
    "pred_delta_total_power_w",
]

ARDUINO_TTL = 5.0
LIGHT_TTL = 10.0
TAPO_TTL = 5.0
DREO_TTL = 35.0


latest_state = {
    "arduino": {
        "recv_ts": None,
        "temperature": None,
        "ambient_light": None,
    },
    "light": {
        "recv_ts": None,
        "light_state": None,
    },
    "tapo": {
        "recv_ts": None,
        "total_power_w": None,
    },
    "dreo": {
        "recv_ts": None,
        "fan_state": None,
    },
}


def iso_utc_now():
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def is_fresh(recv_ts, ttl):
    return recv_ts is not None and (time.time() - recv_ts) <= ttl


def to_float(value):
    if value is None or value == "":
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def median(values):
    values = sorted(values)
    if not values:
        return None
    mid = len(values) // 2
    if len(values) % 2:
        return values[mid]
    return (values[mid - 1] + values[mid]) / 2


def build_current_record():
    arduino_valid = is_fresh(latest_state["arduino"]["recv_ts"], ARDUINO_TTL)
    light_valid = is_fresh(latest_state["light"]["recv_ts"], LIGHT_TTL)
    tapo_valid = is_fresh(latest_state["tapo"]["recv_ts"], TAPO_TTL)
    dreo_valid = is_fresh(latest_state["dreo"]["recv_ts"], DREO_TTL)

    if not (arduino_valid and light_valid and tapo_valid and dreo_valid):
        return None

    return {
        "time": iso_utc_now(),
        "light_state": latest_state["light"]["light_state"],
        "fan_state": latest_state["dreo"]["fan_state"],
        "ambient_light": latest_state["arduino"]["ambient_light"],
        "temperature": latest_state["arduino"]["temperature"],
        "total_power_w": latest_state["tapo"]["total_power_w"],
    }


def aggregate_bucket(records, bucket_ts):
    def mean(column):
        values = [to_float(row.get(column)) for row in records]
        values = [value for value in values if value is not None]
        if not values:
            return None
        return sum(values) / len(values)

    def filtered_median(column, predicate):
        values = []
        for row in records:
            if not predicate(row):
                continue
            value = to_float(row.get(column))
            if value is not None:
                values.append(value)
        return median(values), len(values)

    def last(column):
        for row in reversed(records):
            value = to_float(row.get(column))
            if value is not None:
                return value
        return None

    final_light_state = round(last("light_state"))
    final_fan_state = round(last("fan_state"))

    def matches_final_light(row):
        value = to_float(row.get("light_state"))
        return value is not None and round(value) == final_light_state

    def matches_final_state_pair(row):
        light_value = to_float(row.get("light_state"))
        fan_value = to_float(row.get("fan_state"))
        return (
            light_value is not None
            and fan_value is not None
            and round(light_value) == final_light_state
            and round(fan_value) == final_fan_state
        )

    ambient_light, ambient_count = filtered_median(
        "ambient_light",
        matches_final_light,
    )
    temperature, temperature_count = filtered_median(
        "temperature",
        matches_final_state_pair,
    )
    total_power_w, power_count = filtered_median(
        "total_power_w",
        matches_final_state_pair,
    )
    min_effective_count = min(ambient_count, temperature_count, power_count)

    record = {
        "time": datetime.fromtimestamp(bucket_ts, tz=timezone.utc)
        .isoformat()
        .replace("+00:00", "Z"),
        "light_state": final_light_state,
        "fan_state": final_fan_state,
        "ambient_light": ambient_light,
        "temperature": temperature,
        "total_power_w": total_power_w,
        "ambient_effective_count": ambient_count,
        "temperature_effective_count": temperature_count,
        "power_effective_count": power_count,
        "min_effective_count": min_effective_count,
        "edge_mixed_bucket": int(min_effective_count < 3),
    }
    if any(record[name] is None for name in NODE_NAMES):
        return None
    return record


def make_node_features(record, previous_record, scalers):
    node_types = [1.0 if name in {"light_state", "fan_state"} else 0.0 for name in NODE_NAMES]
    values = [scalers[name].transform(record[name]) for name in NODE_NAMES]
    if previous_record is None:
        deltas = [0.0 for _ in NODE_NAMES]
    else:
        previous_values = [
            scalers[name].transform(previous_record[name]) for name in NODE_NAMES
        ]
        deltas = [
            value - previous_value for value, previous_value in zip(values, previous_values)
        ]

    return [
        [value, delta, node_type]
        for value, delta, node_type in zip(values, deltas, node_types)
    ]


def weighted_error(prediction, target, weights):
    return ((prediction - target) ** 2 * weights).mean().item()


class OnlineGNNGRUIDS:
    def __init__(self, checkpoint, args):
        self.args = args
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        config = checkpoint["config"]
        self.resample_seconds = config["resample_seconds"]
        self.sequence_length = config["sequence_length"]
        self.prediction_horizon = checkpoint.get(
            "prediction_horizon",
            config.get("prediction_horizon", 1),
        )
        self.threshold = args.threshold if args.threshold is not None else checkpoint["threshold"]
        self.target_thresholds = checkpoint.get("target_thresholds", {})

        self.scalers = {
            name: StandardScaler(**values)
            for name, values in checkpoint["scalers"].items()
        }
        self.model = GATGRUPredictor(
            node_feature_size=3,
            graph_hidden_size=config["graph_hidden_size"],
            hidden_size=config["hidden_size"],
            gru_layers=config["gru_layers"],
            dropout=config["dropout"],
            target_size=self.prediction_horizon * len(PHYSICAL_NODES),
            edge_index=build_edge_index(),
            future_control_size=self.prediction_horizon * 4,
        ).to(self.device)
        self.model.load_state_dict(checkpoint["model_state_dict"])
        self.model.eval()

        target_weights = config["target_weights"]
        self.weights = torch.tensor(
            [target_weights[name] for name in PHYSICAL_NODES],
            dtype=torch.float32,
            device=self.device,
        )

        self.current_bucket_ts = None
        self.current_bucket_rows = []
        self.aggregated_records = []
        self.feature_history = []
        self.consecutive_high_error = 0

    def add_record(self, record):
        timestamp = parse_time(record["time"])
        bucket_ts = int(timestamp.timestamp() // self.resample_seconds) * self.resample_seconds

        if self.current_bucket_ts is None:
            self.current_bucket_ts = bucket_ts

        if bucket_ts != self.current_bucket_ts:
            result = self.close_current_bucket()
            self.current_bucket_ts = bucket_ts
            self.current_bucket_rows = [record]
            return result

        self.current_bucket_rows.append(record)
        return None

    def close_current_bucket(self):
        if not self.current_bucket_rows:
            return None

        record = aggregate_bucket(self.current_bucket_rows, self.current_bucket_ts)
        self.current_bucket_rows = []
        if record is None:
            return None

        previous = self.aggregated_records[-1] if self.aggregated_records else None
        feature = make_node_features(record, previous, self.scalers)
        self.aggregated_records.append(record)
        self.feature_history.append(feature)

        required_history = self.sequence_length + self.prediction_horizon
        if len(self.feature_history) < required_history:
            return {
                "time": record["time"],
                "status": "warming_up",
                "history": len(self.feature_history),
                "required_history": required_history,
            }

        target_start_index = len(self.aggregated_records) - self.prediction_horizon
        input_start_index = target_start_index - self.sequence_length
        x_features = self.feature_history[input_start_index:target_start_index]
        target_records = self.aggregated_records[
            target_start_index : target_start_index + self.prediction_horizon
        ]
        previous_for_first_target = self.aggregated_records[target_start_index - 1]

        if any(record.get("edge_mixed_bucket") for record in target_records):
            self.consecutive_high_error = 0
            return {
                "time": target_records[-1]["time"],
                "status": "skipped_edge_bucket",
                "skipped_reason": "prediction target contains edge/mixed bucket",
                "prediction_start_time": target_records[0]["time"],
                "prediction_end_time": target_records[-1]["time"],
                "prediction_horizon": self.prediction_horizon,
                "light_state": target_records[-1]["light_state"],
                "fan_state": target_records[-1]["fan_state"],
            }

        target_deltas = []
        future_control = []
        for horizon_index, target_record in enumerate(target_records):
            previous_record = (
                previous_for_first_target
                if horizon_index == 0
                else target_records[horizon_index - 1]
            )
            future_control.append(
                [
                    self.scalers["light_state"].transform(target_record["light_state"]),
                    self.scalers["fan_state"].transform(target_record["fan_state"]),
                    self.scalers["light_state"].transform(target_record["light_state"])
                    - self.scalers["light_state"].transform(previous_record["light_state"]),
                    self.scalers["fan_state"].transform(target_record["fan_state"])
                    - self.scalers["fan_state"].transform(previous_record["fan_state"]),
                ]
            )
            target_deltas.append(
                [
                    self.scalers[name].transform(target_record[name])
                    - self.scalers[name].transform(previous_record[name])
                    for name in PHYSICAL_NODES
                ]
            )

        x = torch.tensor([x_features], dtype=torch.float32, device=self.device)
        future_control = torch.tensor(
            [future_control],
            dtype=torch.float32,
            device=self.device,
        )
        target = torch.tensor([target_deltas], dtype=torch.float32, device=self.device)
        with torch.no_grad():
            prediction = self.model(x, future_control).view_as(target)
            weighted_target_error = (prediction[0] - target[0]) ** 2 * self.weights
            error = weighted_target_error.mean().item()

        target_errors = {
            name: weighted_target_error[:, index].mean().item()
            for index, name in enumerate(PHYSICAL_NODES)
        }
        target_high_error = 0
        for name, target_error in target_errors.items():
            target_threshold = self.target_thresholds.get(name)
            if target_threshold is not None and target_error > target_threshold:
                target_high_error = 1
                break

        total_high_error = int(error > self.threshold)
        high_error = int(total_high_error or target_high_error)
        if high_error:
            self.consecutive_high_error += 1
        else:
            self.consecutive_high_error = 0

        anomaly = int(self.consecutive_high_error >= self.args.consecutive)
        predicted_values = {}
        actual_values = {}
        predicted_deltas = {}
        actual_deltas = {}
        prediction_cpu = prediction[0].detach().cpu().tolist()
        final_record = target_records[-1]
        predicted_running_values = {
            name: previous_for_first_target[name] for name in PHYSICAL_NODES
        }
        final_predicted_deltas = {}
        final_actual_deltas = {}
        for horizon_index, step_prediction in enumerate(prediction_cpu):
            target_record = target_records[horizon_index]
            previous_record = (
                previous_for_first_target
                if horizon_index == 0
                else target_records[horizon_index - 1]
            )
            for name, value in zip(PHYSICAL_NODES, step_prediction):
                predicted_raw_delta = value * self.scalers[name].std
                actual_raw_delta = target_record[name] - previous_record[name]
                predicted_running_values[name] += predicted_raw_delta
                final_predicted_deltas[name] = predicted_raw_delta
                final_actual_deltas[name] = actual_raw_delta

        for name in PHYSICAL_NODES:
            predicted_values[f"pred_{name}"] = predicted_running_values[name]
            actual_values[f"actual_{name}"] = final_record[name]
            predicted_deltas[f"pred_delta_{name}"] = final_predicted_deltas[name]
            actual_deltas[f"actual_delta_{name}"] = final_actual_deltas[name]

        first_target_record = target_records[0]
        last_target_record = target_records[-1]

        return {
            "time": last_target_record["time"],
            "status": "scored",
            "anomaly": anomaly,
            "high_error": high_error,
            "total_high_error": total_high_error,
            "target_high_error": target_high_error,
            "consecutive_high_error": self.consecutive_high_error,
            "error": error,
            "threshold": self.threshold,
            "prediction_start_time": first_target_record["time"],
            "prediction_end_time": last_target_record["time"],
            "prediction_horizon": self.prediction_horizon,
            "light_state": last_target_record["light_state"],
            "fan_state": last_target_record["fan_state"],
            "err_ambient_light": target_errors["ambient_light"],
            "err_temperature": target_errors["temperature"],
            "err_total_power_w": target_errors["total_power_w"],
            "th_ambient_light": self.target_thresholds.get("ambient_light"),
            "th_temperature": self.target_thresholds.get("temperature"),
            "th_total_power_w": self.target_thresholds.get("total_power_w"),
            **actual_values,
            **predicted_values,
            **actual_deltas,
            **predicted_deltas,
        }


def on_connect(client, userdata, flags, rc, properties=None):
    if rc == 0:
        print("[INFO] Connected to MQTT broker")
        for topic in MQTT_TOPICS:
            client.subscribe(topic)
            print(f"[INFO] Subscribed: {topic}")
    else:
        print(f"[ERROR] MQTT connect failed rc={rc}")


def on_message(client, userdata, msg):
    payload_str = msg.payload.decode("utf-8", errors="ignore")
    try:
        payload = json.loads(payload_str)
    except json.JSONDecodeError:
        return

    now_ts = time.time()
    if msg.topic == "iot/arduino":
        latest_state["arduino"].update(
            recv_ts=now_ts,
            temperature=payload.get("temperature"),
            ambient_light=payload.get("ambient_light"),
        )
    elif msg.topic == "iot/light_state":
        latest_state["light"].update(
            recv_ts=now_ts,
            light_state=payload.get("light_state"),
        )
    elif msg.topic == "iot/tapo_p110":
        latest_state["tapo"].update(
            recv_ts=now_ts,
            total_power_w=payload.get("power_w"),
        )
    elif msg.topic == "iot/dreo_fan":
        latest_state["dreo"].update(
            recv_ts=now_ts,
            fan_state=payload.get("fan_state"),
        )


def write_log(result):
    ONLINE_LOG.parent.mkdir(parents=True, exist_ok=True)
    if ONLINE_LOG.exists() and ONLINE_LOG.stat().st_size > 0:
        with ONLINE_LOG.open("r", newline="", encoding="utf-8") as f:
            first_line = f.readline().strip()
        expected_header = ",".join(LOG_FIELDS)
        if first_line != expected_header:
            backup_path = ONLINE_LOG.with_suffix(f".{int(time.time())}.bak.csv")
            ONLINE_LOG.rename(backup_path)
            print(f"[INFO] Existing online log moved to {backup_path}")

    write_header = not ONLINE_LOG.exists() or ONLINE_LOG.stat().st_size == 0
    with ONLINE_LOG.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=LOG_FIELDS, extrasaction="ignore")
        if write_header:
            writer.writeheader()
        writer.writerow(result)


def parse_args():
    parser = argparse.ArgumentParser(description="Online GAT-GRU IDS over MQTT.")
    parser.add_argument("--model-path", default=MODEL_PATH)
    parser.add_argument("--mqtt-broker", default=MQTT_BROKER)
    parser.add_argument("--mqtt-port", type=int, default=MQTT_PORT)
    parser.add_argument("--alert-topic", default=ALERT_TOPIC)
    parser.add_argument("--threshold", type=float, default=None)
    parser.add_argument("--consecutive", type=int, default=2)
    return parser.parse_args()


def main():
    args = parse_args()
    checkpoint = torch.load(args.model_path, map_location="cpu", weights_only=False)
    if checkpoint.get("prediction_target") != "scaled_delta":
        raise SystemExit(
            "This online script now expects a delta-prediction GAT-GRU model. "
            "Please retrain with train_gnn_gru_ids.py first."
        )
    if "prediction_horizon" not in checkpoint and "prediction_horizon" not in checkpoint.get("config", {}):
        raise SystemExit(
            "This online script now expects a multi-step GAT-GRU model. "
            "Please retrain with the updated train_gnn_gru_ids.py first."
        )
    if not checkpoint.get("future_control_features"):
        raise SystemExit(
            "This online script now expects a conditional GAT-GRU model with "
            "future control features. Please retrain with the updated "
            "train_gnn_gru_ids.py first."
        )
    ids = OnlineGNNGRUIDS(checkpoint, args)

    client = mqtt.Client()
    client.on_connect = on_connect
    client.on_message = on_message
    client.connect(args.mqtt_broker, args.mqtt_port, 60)
    client.loop_start()

    print(f"[INFO] Model: {args.model_path}")
    print(f"[INFO] Resample seconds: {ids.resample_seconds}")
    print(f"[INFO] Sequence length: {ids.sequence_length}")
    print(
        f"[INFO] Prediction horizon: {ids.prediction_horizon} "
        f"steps ({ids.prediction_horizon * ids.resample_seconds}s)"
    )
    print(f"[INFO] Threshold: {ids.threshold:.6f}")
    print(f"[INFO] Publishing alerts to: {args.alert_topic}")

    try:
        while True:
            record = build_current_record()
            if record is not None:
                result = ids.add_record(record)
                if result is not None:
                    message = json.dumps(result, ensure_ascii=False)
                    client.publish(args.alert_topic, message)
                    write_log(result)
                    if result["status"] == "scored":
                        print(
                            "[GNN_GRU_IDS] "
                            f"anomaly={result['anomaly']} "
                            f"high_error={result['high_error']} "
                            f"total_high={result['total_high_error']} "
                            f"target_high={result['target_high_error']} "
                            f"error={result['error']:.6f} "
                            f"threshold={result['threshold']:.6f} "
                            f"err_amb={result['err_ambient_light']:.6f} "
                            f"err_temp={result['err_temperature']:.6f} "
                            f"err_pow={result['err_total_power_w']:.6f} "
                            f"light={result['light_state']} fan={result['fan_state']}"
                        )
                    elif result["status"] == "warming_up":
                        print(
                            "[GNN_GRU_IDS] "
                            f"warming_up={result['history']}/"
                            f"{result['required_history']}"
                        )
                    else:
                        print(
                            "[GNN_GRU_IDS] "
                            f"status={result['status']} "
                            f"reason={result.get('skipped_reason', '-')}"
                        )
            time.sleep(1)
    except KeyboardInterrupt:
        print("Stopped by user")
    finally:
        client.loop_stop()
        client.disconnect()


if __name__ == "__main__":
    main()
