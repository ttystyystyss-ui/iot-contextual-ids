import argparse
import copy
import csv
import json
import math
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import torch
from torch import nn
from torch.utils.data import DataLoader, Dataset


CSV_PATH = "aligned_all_data_clean.csv"
ARTIFACT_DIR = Path("artifacts/gnn_gru_ids_run")

NODE_NAMES = [
    "light_state",
    "fan_state",
    "ambient_light",
    "temperature",
    "total_power_w",
]

CONTROL_NODES = {"light_state", "fan_state"}
PHYSICAL_NODES = ["ambient_light", "temperature", "total_power_w"]
PHYSICAL_INDEXES = [NODE_NAMES.index(name) for name in PHYSICAL_NODES]

# Fixed cyber-physical dependency graph.
# First version: only direct device-state -> physical-response edges + self loops.
DIRECTED_EDGES = [
    ("light_state", "ambient_light"),
    ("light_state", "total_power_w"),
    ("light_state", "temperature"),
    ("fan_state", "total_power_w"),
    ("fan_state", "temperature"),
]


@dataclass
class StandardScaler:
    mean: float
    std: float

    def transform(self, value):
        if value is None:
            return None
        return (value - self.mean) / self.std

    def inverse_transform(self, value):
        return value * self.std + self.mean


@dataclass
class TrainConfig:
    csv_path: str
    resample_seconds: int
    max_gap_seconds: int
    sequence_length: int
    prediction_horizon: int
    hidden_size: int
    graph_hidden_size: int
    gru_layers: int
    dropout: float
    batch_size: int
    epochs: int
    learning_rate: float
    weight_decay: float
    train_ratio: float
    threshold_percentile: float
    target_weights: dict


class GraphAttentionLayer(nn.Module):
    def __init__(self, node_feature_size, graph_hidden_size, edge_index):
        super().__init__()
        self.node_projection = nn.Linear(node_feature_size, graph_hidden_size, bias=False)
        self.attention_projection = nn.Linear(graph_hidden_size * 2, 1, bias=False)
        self.register_buffer("edge_index", edge_index)
        self.last_attention = None

    def forward(self, x):
        # x: [batch_seq, nodes, node_features]
        h = self.node_projection(x)
        source_index = self.edge_index[0]
        target_index = self.edge_index[1]
        source_h = h[:, source_index, :]
        target_h = h[:, target_index, :]

        scores = self.attention_projection(
            torch.cat([target_h, source_h], dim=-1)
        ).squeeze(-1)
        scores = torch.nn.functional.leaky_relu(scores, negative_slope=0.2)

        output = torch.zeros_like(h)
        attention = torch.zeros_like(scores)
        for target in range(len(NODE_NAMES)):
            mask = target_index == target
            if not torch.any(mask):
                continue
            target_scores = scores[:, mask]
            target_attention = torch.softmax(target_scores, dim=1)
            attention[:, mask] = target_attention
            messages = source_h[:, mask, :] * target_attention.unsqueeze(-1)
            output[:, target, :] = messages.sum(dim=1)

        self.last_attention = attention.detach()
        return output


class GATGRUPredictor(nn.Module):
    def __init__(
        self,
        node_feature_size,
        graph_hidden_size,
        hidden_size,
        gru_layers,
        dropout,
        target_size,
        edge_index,
        future_control_size=0,
    ):
        super().__init__()
        self.future_control_size = future_control_size
        self.gat = GraphAttentionLayer(
            node_feature_size=node_feature_size,
            graph_hidden_size=graph_hidden_size,
            edge_index=edge_index,
        )
        self.node_projector = nn.Sequential(
            nn.ReLU(),
            nn.Linear(graph_hidden_size, graph_hidden_size),
            nn.ReLU(),
        )
        self.gru = nn.GRU(
            input_size=len(NODE_NAMES) * graph_hidden_size,
            hidden_size=hidden_size,
            num_layers=gru_layers,
            batch_first=True,
            dropout=dropout if gru_layers > 1 else 0.0,
        )
        if future_control_size:
            self.future_control_projector = nn.Sequential(
                nn.Linear(future_control_size, hidden_size),
                nn.ReLU(),
                nn.Dropout(dropout),
            )
            head_input_size = hidden_size * 2
        else:
            self.future_control_projector = None
            head_input_size = hidden_size

        self.head = nn.Sequential(
            nn.Linear(head_input_size, hidden_size),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_size, target_size),
        )

    def forward(self, x, future_control=None):
        # x: [batch, seq, nodes, node_features]
        batch_size, seq_len, node_count, feature_count = x.shape
        x = x.reshape(batch_size * seq_len, node_count, feature_count)
        x = self.gat(x)
        x = self.node_projector(x)
        x = x.reshape(batch_size, seq_len, node_count * x.shape[-1])
        _, hidden = self.gru(x)
        hidden = hidden[-1]

        if self.future_control_projector is not None:
            if future_control is None:
                raise ValueError("future_control is required for this model.")
            control_embedding = self.future_control_projector(
                future_control.reshape(future_control.shape[0], -1)
            )
            hidden = torch.cat([hidden, control_embedding], dim=1)

        return self.head(hidden)


class SequenceDataset(Dataset):
    def __init__(self, samples):
        self.samples = samples

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, index):
        x, future_control, y = self.samples[index][:3]
        return (
            torch.tensor(x, dtype=torch.float32),
            torch.tensor(future_control, dtype=torch.float32),
            torch.tensor(y, dtype=torch.float32),
        )


def parse_time(value):
    return datetime.fromisoformat(value.replace("Z", "+00:00"))


def to_float(value):
    if value is None or value == "":
        return None
    try:
        parsed = float(value)
    except ValueError:
        return None
    if math.isnan(parsed) or math.isinf(parsed):
        return None
    return parsed


def percentile(values, pct):
    if not values:
        return None
    values = sorted(values)
    index = int(round((len(values) - 1) * pct / 100))
    return values[max(0, min(index, len(values) - 1))]


def median(values):
    values = sorted(values)
    if not values:
        return None
    mid = len(values) // 2
    if len(values) % 2:
        return values[mid]
    return (values[mid - 1] + values[mid]) / 2


def load_rows(csv_path):
    with open(csv_path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def aggregate_rows(rows, resample_seconds):
    buckets = {}
    for row in rows:
        required = [
            "time",
            "light_state",
            "fan_state",
            "ambient_light",
            "temperature",
            "fan_power_w",
        ]
        if any(row.get(column, "") == "" for column in required):
            continue

        timestamp = parse_time(row["time"])
        bucket_ts = int(timestamp.timestamp() // resample_seconds) * resample_seconds
        buckets.setdefault(bucket_ts, []).append(row)

    aggregated = []
    for bucket_ts in sorted(buckets):
        bucket = buckets[bucket_ts]

        def mean(column):
            values = [to_float(row.get(column)) for row in bucket]
            values = [value for value in values if value is not None]
            if not values:
                return None
            return sum(values) / len(values)

        def filtered_median(column, predicate):
            values = []
            for row in bucket:
                if not predicate(row):
                    continue
                value = to_float(row.get(column))
                if value is not None:
                    values.append(value)
            return median(values), len(values)

        def last(column):
            for row in reversed(bucket):
                value = to_float(row.get(column))
                if value is not None:
                    return value
            return None

        final_light_state = round(last("light_state"))
        final_fan_state = round(last("fan_state"))

        def matches_final_light(row):
            value = to_float(row.get("light_state"))
            return value is not None and round(value) == final_light_state

        def matches_final_state_pair(row):
            light_value = to_float(row.get("light_state"))
            fan_value = to_float(row.get("fan_state"))
            return (
                light_value is not None
                and fan_value is not None
                and round(light_value) == final_light_state
                and round(fan_value) == final_fan_state
            )

        ambient_light, ambient_count = filtered_median(
            "ambient_light",
            matches_final_light,
        )
        temperature, temperature_count = filtered_median(
            "temperature",
            matches_final_state_pair,
        )
        total_power_w, power_count = filtered_median(
            "fan_power_w",
            matches_final_state_pair,
        )
        min_effective_count = min(ambient_count, temperature_count, power_count)

        record = {
            "time": datetime.fromtimestamp(bucket_ts, tz=timezone.utc)
            .isoformat()
            .replace("+00:00", "Z"),
            "light_state": final_light_state,
            "fan_state": final_fan_state,
            "ambient_light": ambient_light,
            "temperature": temperature,
            "total_power_w": total_power_w,
            "row_count": len(bucket),
            "max_dreo_age_seconds": mean("dreo_age_seconds"),
            "ambient_effective_count": ambient_count,
            "temperature_effective_count": temperature_count,
            "power_effective_count": power_count,
            "min_effective_count": min_effective_count,
            "edge_mixed_bucket": int(min_effective_count < 3),
        }

        if all(record[name] is not None for name in NODE_NAMES):
            aggregated.append(record)

    return aggregated


def split_records_by_gap(records, max_gap_seconds):
    if not records:
        return []

    segments = [[records[0]]]
    for record in records[1:]:
        previous_time = parse_time(segments[-1][-1]["time"])
        current_time = parse_time(record["time"])
        gap_seconds = (current_time - previous_time).total_seconds()

        if gap_seconds > max_gap_seconds:
            segments.append([record])
        else:
            segments[-1].append(record)

    return segments


def build_scalers(records, train_end):
    scalers = {}
    train_records = records[:train_end]
    for name in NODE_NAMES:
        values = [record[name] for record in train_records]
        mean_value = sum(values) / len(values)
        variance = sum((value - mean_value) ** 2 for value in values) / len(values)
        std_value = math.sqrt(variance) or 1.0
        scalers[name] = StandardScaler(mean=mean_value, std=std_value)
    return scalers


def build_edge_index():
    node_to_index = {name: index for index, name in enumerate(NODE_NAMES)}
    edges = []

    for name in NODE_NAMES:
        index = node_to_index[name]
        edges.append((index, index))

    for source, target in DIRECTED_EDGES:
        source_index = node_to_index[source]
        target_index = node_to_index[target]
        # Edge direction: target node receives message from source node.
        edges.append((source_index, target_index))

    return torch.tensor(edges, dtype=torch.long).t().contiguous()


def make_node_features(records, scalers):
    node_types = [1.0 if name in CONTROL_NODES else 0.0 for name in NODE_NAMES]
    features = []
    previous_values = None

    for record in records:
        values = [scalers[name].transform(record[name]) for name in NODE_NAMES]
        if previous_values is None:
            deltas = [0.0 for _ in NODE_NAMES]
        else:
            deltas = [value - previous for value, previous in zip(values, previous_values)]

        step_features = []
        for value, delta, node_type in zip(values, deltas, node_types):
            step_features.append([value, delta, node_type])

        features.append(step_features)
        previous_values = values

    return features


def make_samples(features, records, scalers, sequence_length, prediction_horizon):
    samples = []
    for end_index in range(sequence_length, len(records) - prediction_horizon + 1):
        x = features[end_index - sequence_length : end_index]
        future_records = records[end_index : end_index + prediction_horizon]
        if any(record.get("edge_mixed_bucket") for record in future_records):
            continue

        y = []
        future_control = []
        future_metadata = []
        for horizon_index in range(prediction_horizon):
            target_index = end_index + horizon_index
            previous_record = records[target_index - 1]
            target_record = records[target_index]
            future_control.append(
                [
                    scalers["light_state"].transform(target_record["light_state"]),
                    scalers["fan_state"].transform(target_record["fan_state"]),
                    scalers["light_state"].transform(target_record["light_state"])
                    - scalers["light_state"].transform(previous_record["light_state"]),
                    scalers["fan_state"].transform(target_record["fan_state"])
                    - scalers["fan_state"].transform(previous_record["fan_state"]),
                ]
            )
            y.append(
                [
                    scalers[name].transform(target_record[name])
                    - scalers[name].transform(previous_record[name])
                    for name in PHYSICAL_NODES
                ]
            )
            step_metadata = {
                "horizon_step": horizon_index + 1,
                "time": target_record["time"],
                "previous_time": previous_record["time"],
            }
            for name in PHYSICAL_NODES:
                step_metadata[f"previous_{name}"] = previous_record[name]
                step_metadata[f"actual_{name}"] = target_record[name]
                step_metadata[f"actual_delta_{name}"] = (
                    target_record[name] - previous_record[name]
                )
            future_metadata.append(step_metadata)

        target_record = records[end_index]
        metadata = {
            "light_state": target_record["light_state"],
            "fan_state": target_record["fan_state"],
            "future": future_metadata,
        }
        samples.append((x, future_control, y, metadata))
    return samples


def make_segmented_samples(segments, scalers, sequence_length, prediction_horizon):
    samples = []
    usable_segments = []
    for segment_index, segment in enumerate(segments, start=1):
        if len(segment) < sequence_length + prediction_horizon:
            continue

        features = make_node_features(segment, scalers)
        segment_samples = make_samples(
            features,
            segment,
            scalers,
            sequence_length,
            prediction_horizon,
        )
        samples.extend(segment_samples)
        usable_segments.append(
            {
                "segment_index": segment_index,
                "start": segment[0]["time"],
                "end": segment[-1]["time"],
                "records": len(segment),
                "samples": len(segment_samples),
            }
        )
    return samples, usable_segments


def weighted_mse(prediction, target, weights):
    error = (prediction - target) ** 2
    return (error * weights).mean()


def evaluate_errors(model, loader, weights, device):
    model.eval()
    losses = []
    errors = []
    target_errors = {name: [] for name in PHYSICAL_NODES}
    predictions = []
    targets = []
    with torch.no_grad():
        for x, future_control, y in loader:
            x = x.to(device)
            future_control = future_control.to(device)
            y = y.to(device)
            pred = model(x, future_control).view_as(y)
            batch_loss = weighted_mse(pred, y, weights)
            losses.append(batch_loss.item())
            weighted_target_error = (pred - y) ** 2 * weights
            per_sample_error = weighted_target_error.mean(dim=(1, 2))
            errors.extend(per_sample_error.detach().cpu().tolist())
            for target_index, target_name in enumerate(PHYSICAL_NODES):
                target_errors[target_name].extend(
                    weighted_target_error[:, :, target_index]
                    .mean(dim=1)
                    .detach()
                    .cpu()
                    .tolist()
                )
            predictions.extend(pred.detach().cpu().tolist())
            targets.extend(y.detach().cpu().tolist())

    mean_loss = sum(losses) / len(losses) if losses else None
    return mean_loss, errors, target_errors, predictions, targets


def mean_target_errors(target_errors):
    return {
        name: (sum(errors) / len(errors) if errors else None)
        for name, errors in target_errors.items()
    }


def write_prediction_details(path, samples, predictions, targets, scalers):
    if not samples:
        return

    fieldnames = [
        "time",
        "previous_time",
        "horizon_step",
        "light_state",
        "fan_state",
    ]
    for name in PHYSICAL_NODES:
        fieldnames.extend(
            [
                f"previous_{name}",
                f"actual_{name}",
                f"pred_{name}",
                f"actual_delta_{name}",
                f"pred_delta_{name}",
                f"err_{name}",
            ]
        )

    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for sample, prediction, target in zip(samples, predictions, targets):
            metadata = sample[3]
            predicted_previous_values = {
                name: metadata["future"][0][f"previous_{name}"]
                for name in PHYSICAL_NODES
            }
            for horizon_index, step_metadata in enumerate(metadata["future"]):
                row = {
                    "time": step_metadata["time"],
                    "previous_time": step_metadata["previous_time"],
                    "horizon_step": step_metadata["horizon_step"],
                    "light_state": metadata["light_state"],
                    "fan_state": metadata["fan_state"],
                }
                for target_index, name in enumerate(PHYSICAL_NODES):
                    pred_delta = prediction[horizon_index][target_index] * scalers[name].std
                    actual_delta = target[horizon_index][target_index] * scalers[name].std
                    previous_value = step_metadata[f"previous_{name}"]
                    predicted_previous_values[name] += pred_delta
                    row[f"previous_{name}"] = previous_value
                    row[f"actual_{name}"] = step_metadata[f"actual_{name}"]
                    row[f"pred_{name}"] = predicted_previous_values[name]
                    row[f"actual_delta_{name}"] = actual_delta
                    row[f"pred_delta_{name}"] = pred_delta
                    row[f"err_{name}"] = (
                        prediction[horizon_index][target_index]
                        - target[horizon_index][target_index]
                    ) ** 2
                writer.writerow(row)


def attention_summary(model, loader, device):
    model.eval()
    edge_index = model.gat.edge_index.detach().cpu()
    edge_names = [
        {
            "source": NODE_NAMES[int(source)],
            "target": NODE_NAMES[int(target)],
        }
        for source, target in zip(edge_index[0], edge_index[1])
    ]
    sums = torch.zeros(edge_index.shape[1], dtype=torch.float64)
    counts = 0

    with torch.no_grad():
        for x, future_control, _ in loader:
            x = x.to(device)
            future_control = future_control.to(device)
            _ = model(x, future_control)
            attention = model.gat.last_attention
            if attention is None:
                continue
            sums += attention.detach().cpu().double().sum(dim=0)
            counts += attention.shape[0]

    if counts == 0:
        return []

    means = (sums / counts).tolist()
    return [
        {
            "source": edge["source"],
            "target": edge["target"],
            "mean_attention": mean,
        }
        for edge, mean in zip(edge_names, means)
    ]


def train(args):
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)

    rows = load_rows(args.csv_path)
    records = aggregate_rows(rows, args.resample_seconds)
    if len(records) < args.sequence_length + 20:
        raise SystemExit(
            f"Not enough aggregated records: {len(records)}. "
            f"Collect more data or reduce --sequence-length."
        )

    segments = split_records_by_gap(records, args.max_gap_seconds)

    print("[INFO] Aggregated segments:")
    for index, segment in enumerate(segments, start=1):
        print(
            f"  segment {index}: records={len(segment)} "
            f"start={segment[0]['time']} end={segment[-1]['time']}"
        )

    train_end = int(len(records) * args.train_ratio)
    scalers = build_scalers(records, train_end)

    split_time = parse_time(records[train_end]["time"]) if train_end < len(records) else parse_time(records[-1]["time"])
    train_segments = []
    val_segments = []
    for segment in segments:
        segment_train = [record for record in segment if parse_time(record["time"]) < split_time]
        segment_val = [record for record in segment if parse_time(record["time"]) >= split_time]
        if segment_train:
            train_segments.append(segment_train)
        if segment_val:
            val_segments.append(segment_val)

    train_samples, train_segment_summary = make_segmented_samples(
        train_segments, scalers, args.sequence_length, args.prediction_horizon
    )
    val_samples, val_segment_summary = make_segmented_samples(
        val_segments, scalers, args.sequence_length, args.prediction_horizon
    )

    print("[INFO] Usable train segments:")
    for summary in train_segment_summary:
        print(
            f"  segment {summary['segment_index']}: "
            f"records={summary['records']} samples={summary['samples']}"
        )
    print("[INFO] Usable val segments:")
    for summary in val_segment_summary:
        print(
            f"  segment {summary['segment_index']}: "
            f"records={summary['records']} samples={summary['samples']}"
        )

    if not val_samples:
        raise SystemExit("Validation split is empty. Collect more data.")
    if not train_samples:
        raise SystemExit("Training split is empty. Collect more data.")

    train_loader = DataLoader(
        SequenceDataset(train_samples),
        batch_size=args.batch_size,
        shuffle=True,
    )
    val_loader = DataLoader(
        SequenceDataset(val_samples),
        batch_size=args.batch_size,
        shuffle=False,
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    edge_index = build_edge_index().to(device)
    model = GATGRUPredictor(
        node_feature_size=3,
        graph_hidden_size=args.graph_hidden_size,
        hidden_size=args.hidden_size,
        gru_layers=args.gru_layers,
        dropout=args.dropout,
        target_size=args.prediction_horizon * len(PHYSICAL_NODES),
        edge_index=edge_index,
        future_control_size=args.prediction_horizon * 4,
    ).to(device)

    target_weights = torch.tensor(
        [
            args.ambient_weight,
            args.temperature_weight,
            args.power_weight,
        ],
        dtype=torch.float32,
        device=device,
    )
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.learning_rate,
        weight_decay=args.weight_decay,
    )

    best_val_loss = float("inf")
    best_state = None
    history = []

    for epoch in range(1, args.epochs + 1):
        model.train()
        train_losses = []
        for x, future_control, y in train_loader:
            x = x.to(device)
            future_control = future_control.to(device)
            y = y.to(device)
            optimizer.zero_grad()
            pred = model(x, future_control).view_as(y)
            loss = weighted_mse(pred, y, target_weights)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), 1.0)
            optimizer.step()
            train_losses.append(loss.item())

        train_loss = sum(train_losses) / len(train_losses)
        train_epoch_loss, _, train_epoch_target_errors, _, _ = evaluate_errors(
            model, train_loader, target_weights, device
        )
        val_loss, _, val_epoch_target_errors, _, _ = evaluate_errors(
            model, val_loader, target_weights, device
        )
        train_target_means = mean_target_errors(train_epoch_target_errors)
        val_target_means = mean_target_errors(val_epoch_target_errors)
        history_row = {
            "epoch": epoch,
            "train_loss": train_epoch_loss,
            "val_loss": val_loss,
        }
        for name in PHYSICAL_NODES:
            history_row[f"train_{name}_error"] = train_target_means[name]
            history_row[f"val_{name}_error"] = val_target_means[name]
        history.append(history_row)

        if val_loss < best_val_loss:
            best_val_loss = val_loss
            best_state = copy.deepcopy(model.state_dict())

        if epoch == 1 or epoch % 10 == 0 or epoch == args.epochs:
            print(
                f"Epoch {epoch:03d} | "
                f"train_loss={train_loss:.6f} | val_loss={val_loss:.6f}"
            )

    model.load_state_dict(best_state)
    train_eval_loader = DataLoader(
        SequenceDataset(train_samples),
        batch_size=args.batch_size,
        shuffle=False,
    )
    train_loss, train_errors, train_target_errors, _, _ = evaluate_errors(
        model, train_eval_loader, target_weights, device
    )
    val_loss, val_errors, val_target_errors, val_predictions, val_targets = evaluate_errors(
        model, val_loader, target_weights, device
    )
    threshold = percentile(val_errors, args.threshold_percentile)
    target_thresholds = {
        name: percentile(errors, args.threshold_percentile)
        for name, errors in val_target_errors.items()
    }
    attention = attention_summary(model, val_loader, device)

    config = TrainConfig(
        csv_path=args.csv_path,
        resample_seconds=args.resample_seconds,
        max_gap_seconds=args.max_gap_seconds,
        sequence_length=args.sequence_length,
        prediction_horizon=args.prediction_horizon,
        hidden_size=args.hidden_size,
        graph_hidden_size=args.graph_hidden_size,
        gru_layers=args.gru_layers,
        dropout=args.dropout,
        batch_size=args.batch_size,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        weight_decay=args.weight_decay,
        train_ratio=args.train_ratio,
        threshold_percentile=args.threshold_percentile,
        target_weights={
            "ambient_light": args.ambient_weight,
            "temperature": args.temperature_weight,
            "total_power_w": args.power_weight,
        },
    )

    checkpoint = {
        "architecture": "conditional_fixed_graph_gat_gru_delta_predictor",
        "prediction_target": "scaled_delta",
        "prediction_horizon": args.prediction_horizon,
        "future_control_features": [
            "light_state",
            "fan_state",
            "delta_light_state",
            "delta_fan_state",
        ],
        "node_names": NODE_NAMES,
        "physical_nodes": PHYSICAL_NODES,
        "directed_edges": DIRECTED_EDGES,
        "edge_index": edge_index.detach().cpu().tolist(),
        "config": asdict(config),
        "scalers": {name: asdict(scaler) for name, scaler in scalers.items()},
        "threshold": threshold,
        "target_thresholds": target_thresholds,
        "threshold_percentile": args.threshold_percentile,
        "model_state_dict": model.state_dict(),
    }

    torch.save(checkpoint, ARTIFACT_DIR / "gnn_gru_ids.pt")
    with open(ARTIFACT_DIR / "train_history.json", "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2)
    write_prediction_details(
        ARTIFACT_DIR / "val_predictions.csv",
        val_samples,
        val_predictions,
        val_targets,
        scalers,
    )
    with open(ARTIFACT_DIR / "metrics.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "raw_rows": len(rows),
                "aggregated_records": len(records),
                "edge_mixed_buckets": sum(
                    1 for record in records if record.get("edge_mixed_bucket")
                ),
                "segments": [
                    {
                        "start": segment[0]["time"],
                        "end": segment[-1]["time"],
                        "records": len(segment),
                    }
                    for segment in segments
                ],
                "train_segments": train_segment_summary,
                "val_segments": val_segment_summary,
                "train_samples": len(train_samples),
                "val_samples": len(val_samples),
                "best_val_loss": best_val_loss,
                "final_train_loss": train_loss,
                "final_val_loss": val_loss,
                "train_error_median": percentile(train_errors, 50),
                "train_error_p95": percentile(train_errors, 95),
                "val_error_median": percentile(val_errors, 50),
                "val_error_p95": percentile(val_errors, 95),
                "threshold": threshold,
                "target_thresholds": target_thresholds,
                "train_target_error_median": {
                    name: percentile(errors, 50)
                    for name, errors in train_target_errors.items()
                },
                "train_target_error_p95": {
                    name: percentile(errors, 95)
                    for name, errors in train_target_errors.items()
                },
                "val_target_error_median": {
                    name: percentile(errors, 50)
                    for name, errors in val_target_errors.items()
                },
                "val_target_error_p95": {
                    name: percentile(errors, 95)
                    for name, errors in val_target_errors.items()
                },
            },
            f,
            indent=2,
        )
    with open(ARTIFACT_DIR / "attention_summary.json", "w", encoding="utf-8") as f:
        json.dump(attention, f, indent=2)

    print(f"[INFO] Aggregated records: {len(records)}")
    print(f"[INFO] Train samples: {len(train_samples)}")
    print(f"[INFO] Val samples: {len(val_samples)}")
    print(
        f"[INFO] Prediction horizon: {args.prediction_horizon} "
        f"steps ({args.prediction_horizon * args.resample_seconds}s)"
    )
    print(f"[INFO] Threshold: {threshold:.6f}")
    print("[INFO] Target thresholds:")
    for name, value in target_thresholds.items():
        print(f"  {name}: {value:.6f}")
    print("[INFO] Mean validation attention:")
    for item in attention:
        if item["source"] != item["target"]:
            print(
                f"  {item['source']} -> {item['target']}: "
                f"{item['mean_attention']:.4f}"
            )
    print(f"[INFO] Saved model to: {ARTIFACT_DIR / 'gnn_gru_ids.pt'}")


def parse_args():
    parser = argparse.ArgumentParser(
        description="Train a fixed-graph GAT + GRU contextual IDS model."
    )
    parser.add_argument("--csv-path", default=CSV_PATH)
    parser.add_argument("--resample-seconds", type=int, default=10)
    parser.add_argument("--max-gap-seconds", type=int, default=30)
    parser.add_argument("--sequence-length", type=int, default=12)
    parser.add_argument("--prediction-horizon", type=int, default=3)
    parser.add_argument("--graph-hidden-size", type=int, default=16)
    parser.add_argument("--hidden-size", type=int, default=64)
    parser.add_argument("--gru-layers", type=int, default=1)
    parser.add_argument("--dropout", type=float, default=0.3)
    parser.add_argument("--batch-size", type=int, default=64)
    parser.add_argument("--epochs", type=int, default=80)
    parser.add_argument("--learning-rate", type=float, default=3e-4)
    parser.add_argument("--weight-decay", type=float, default=1e-4)
    parser.add_argument("--train-ratio", type=float, default=0.8)
    parser.add_argument("--threshold-percentile", type=float, default=99.0)
    parser.add_argument("--ambient-weight", type=float, default=1.0)
    parser.add_argument("--temperature-weight", type=float, default=0.3)
    parser.add_argument("--humidity-weight", type=float, default=0.0, help=argparse.SUPPRESS)
    parser.add_argument("--power-weight", type=float, default=1.0)
    return parser.parse_args()


def main():
    args = parse_args()
    train(args)


if __name__ == "__main__":
    main()
