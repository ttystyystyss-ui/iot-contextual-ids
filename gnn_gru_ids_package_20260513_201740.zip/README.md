﻿# GNN-GRU IDS Package

This package contains the current GAT/GNN + GRU IDS model code, dataset, trained model artifact, training metrics, validation predictions, and latest online detection log.

## Main Files

- code/train_gnn_gru_ids.py: training script for the current GNN-GRU IDS model.
- code/online_gnn_gru_ids_mqtt.py: online MQTT IDS detection script.
- data/aligned_all_data_clean.csv: current aligned dataset used for training/evaluation.
- artifacts/gnn_gru_ids_run/gnn_gru_ids.pt: trained PyTorch checkpoint.
- artifacts/gnn_gru_ids_run/metrics.json: model metrics and thresholds.
- artifacts/gnn_gru_ids_run/train_history.json: epoch-by-epoch training history.
- artifacts/gnn_gru_ids_run/attention_summary.json: learned attention summary.
- artifacts/gnn_gru_ids_run/val_predictions.csv: validation prediction details.
- logs/gnn_gru_ids_online_log.csv: latest online detection log.
- collection_code/: scripts used for MQTT collection/control, included for reproducibility.

## Run Training

From the package root:

`powershell
python .\code\train_gnn_gru_ids.py --csv-path .\data\aligned_all_data_clean.csv --output-dir .\artifacts\gnn_gru_ids_run --epochs 80 --learning-rate 0.0003 --dropout 0.3 --weight-decay 0.001 --sequence-length 12 --prediction-horizon 3
`

## Run Online Detection

`powershell
python .\code\online_gnn_gru_ids_mqtt.py --model-path .\artifacts\gnn_gru_ids_run\gnn_gru_ids.pt
`

Optional threshold override example:

`powershell
python .\code\online_gnn_gru_ids_mqtt.py --model-path .\artifacts\gnn_gru_ids_run\gnn_gru_ids.pt --threshold 0.2 --consecutive 2
`

## Notes

The current model uses 10-second aggregated buckets, future horizon 3 steps, and predicts future physical deltas for ambient_light, temperature, and total_power_w conditioned on light_state/fan_state future controls.
